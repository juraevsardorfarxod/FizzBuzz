// let age=-23;
// function groupAge(age=10) {
//    if(age>=0 && age<12) {
//       return "Baby";
//    } else if(age>=12 && age<16) {
//       return "Teeneger";
//    } else if(age>=16 && age<55) {
//       return "Adult";
//    } else if(age>=55 && age<120) {
//       return "Old";
//    } else if(age>=120) {
//       return "You hit the record";
//    } else {
//       return "You are not a man";
//    }
// }
// console.log(groupAge(15));

let elfizzbuzzForm=document.querySelector('.fizzbuzz_form');
let elUserInput=document.querySelector('.user_input');
let elresultFizzbuzz=document.querySelector('.result_fizzbuzz');
elfizzbuzzForm.addEventListener('submit', function(event) {
   event.preventDefault();
   let inputValue=elUserInput.value.trim()-0;
   let result='';
   if(inputValue%3!=0 && inputValue%5!=0) {
      result = inputValue;
   } else if(inputValue%3==0 && inputValue%5==0) {
      result = 'fizzbuzz';
   } else if(inputValue%3==0) {
      result = 'fizz';
   } else {
      result = 'buzz';
   }
   elresultFizzbuzz.textContent=result;
})